public class Absolut extends Vodka {
    @Override
    public String brand(){return "Absolut";};
}
