abstract class Fermented extends Alcoholic {
    private final String creationType = "Fermentation";

    @Override
    String getCreationType() { return creationType; }
    abstract String fermentedType();
}