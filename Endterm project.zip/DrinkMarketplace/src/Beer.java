abstract class Beer extends Fermented {
    @Override
    public String fermentedType(){return "Beer";}
    abstract String brand();
}