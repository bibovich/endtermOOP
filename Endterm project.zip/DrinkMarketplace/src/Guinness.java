public class Guinness extends Beer {
    @Override
    public String brand(){return "Guinness";};
}
