import java.io.FileNotFoundException;
import java.sql.*;
import java.util.Scanner;

public class SQL {
    Scanner scanner = new Scanner(System.in);

    public void insertData(int id, String name, float volume, String brand, float price, boolean isAlcoholicBoolean, String creationType, String drinkType){
        try(Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()){

            String isAlcoholic;

            if (isAlcoholicBoolean == true){
                isAlcoholic = "Alcoholic";
            }else{
                isAlcoholic = "NonAlcoholic";
            }

            PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO drinktable(id, name, volume, brand, price, isAlcoholic, creationType, drinkType) values(?, ?, ?, ?, ?, ?, ?, ?);");
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, name);
            preparedStatement.setDouble(3, volume);
            preparedStatement.setString(4, brand);
            preparedStatement.setDouble(5, price);
            preparedStatement.setString(6, isAlcoholic);
            preparedStatement.setString(7, creationType);
            preparedStatement.setString(8, drinkType);
            preparedStatement.executeUpdate();

        }catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void readData() {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
            String query = "SELECT * FROM drinktable";
            ResultSet rs = statement.executeQuery(query);

            while (rs.next())
            {
                int ID = rs.getInt("id");
                String name = rs.getString("name");
                float volume = rs.getFloat("volume");
                String brand = rs.getString("brand");
                float price = rs.getFloat("price");
                String isAlcoholic = rs.getString("isAlcoholic");
                String creationType = rs.getString("creationType");
                String drinkType = rs.getString("drinkType");

                System.out.format("%s, %s, %s, %s, %s, %s, %s, %s\n", ID, name, volume, brand, price, isAlcoholic, creationType,  drinkType);
            }
            System.out.print("\n");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateIdData(int newId, int id){
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
            PreparedStatement preparedStatement = conn.prepareStatement("UPDATE drinktable SET id=? WHERE ID=?");
            preparedStatement.setInt(1,newId);
            preparedStatement.setInt(2, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateNameData(String newName, int id){
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
            PreparedStatement preparedStatement = conn.prepareStatement("UPDATE drinktable SET name=? WHERE ID=?");
            preparedStatement.setString(1,newName);
            preparedStatement.setInt(2, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateVolumeData(float newVolume, int id){
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
            PreparedStatement preparedStatement = conn.prepareStatement("UPDATE drinktable SET volume=? WHERE ID=?");
            preparedStatement.setFloat(1,newVolume);
            preparedStatement.setInt(2, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateBrandData(String newBrand, boolean newIsAlcoholic, String newCreationType, String newDrinkType, int id){
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
            String isA;
            if (newIsAlcoholic == true){
                isA = "Alcoholic";
            }else{
                isA = "NonAlcoholic";
            }

            PreparedStatement preparedStatement = conn.prepareStatement("UPDATE drinktable SET brand=?, isAlcoholic=?, creationType=?, drinkType=? WHERE ID=?");
            preparedStatement.setString(1, newBrand);
            preparedStatement.setString(2, isA);
            preparedStatement.setString(3, newCreationType);
            preparedStatement.setString(4, newDrinkType);
            preparedStatement.setInt(5, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePriceData(float newPrice, int id){
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
            PreparedStatement preparedStatement = conn.prepareStatement("UPDATE drinktable SET price=? WHERE ID=?");
            preparedStatement.setFloat(1,newPrice);
            preparedStatement.setInt(2, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteData(int id){
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
            PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM drinktable WHERE ID=?");
            preparedStatement.setInt(1,id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteAllData(){
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
            PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM drinktable");
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void searchData(int type){
        switch(type){
            case 1:
                System.out.print("Write id: ");
                int idSearch = scanner.nextInt();
                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
                    PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM drinktable WHERE id = ? ");
                    preparedStatement.setInt(1, idSearch);
                    ResultSet rs = preparedStatement.executeQuery();
                    System.out.print("\n");

                    while (rs.next())
                    {
                        int ID = rs.getInt("id");
                        String name = rs.getString("name");
                        float volume = rs.getFloat("volume");
                        String brand = rs.getString("brand");
                        float price = rs.getFloat("price");
                        String isAlcoholic = rs.getString("isAlcoholic");
                        String creationType = rs.getString("creationType");
                        String drinkType = rs.getString("drinkType");

                        System.out.format("%s, %s, %s, %s, %s, %s, %s, %s\n", ID, name, volume, brand, price, isAlcoholic, creationType,  drinkType);
                    }
                    System.out.print("\n");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 2:
                System.out.print("Write name: ");
                String nameSearch = scanner.nextLine();
                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
                    PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM drinktable WHERE name = ? ");
                    preparedStatement.setString(1, nameSearch);
                    ResultSet rs = preparedStatement.executeQuery();
                    System.out.print("\n");

                    while (rs.next())
                    {
                        int ID = rs.getInt("id");
                        String name = rs.getString("name");
                        float volume = rs.getFloat("volume");
                        String brand = rs.getString("brand");
                        float price = rs.getFloat("price");
                        String isAlcoholic = rs.getString("isAlcoholic");
                        String creationType = rs.getString("creationType");
                        String drinkType = rs.getString("drinkType");

                        System.out.format("%s, %s, %s, %s, %s, %s, %s, %s\n", ID, name, volume, brand, price, isAlcoholic, creationType,  drinkType);
                    }
                    System.out.print("\n");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 3:
                System.out.print("Write volume: ");
                float volumeSearch = scanner.nextFloat();
                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
                    PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM drinktable WHERE volume = ? ");
                    preparedStatement.setDouble(1, volumeSearch);
                    ResultSet rs = preparedStatement.executeQuery();
                    System.out.print("\n");

                    while (rs.next())
                    {
                        int ID = rs.getInt("id");
                        String name = rs.getString("name");
                        float volume = rs.getFloat("volume");
                        String brand = rs.getString("brand");
                        float price = rs.getFloat("price");
                        String isAlcoholic = rs.getString("isAlcoholic");
                        String creationType = rs.getString("creationType");
                        String drinkType = rs.getString("drinkType");

                        System.out.format("%s, %s, %s, %s, %s, %s, %s, %s\n", ID, name, volume, brand, price, isAlcoholic, creationType,  drinkType);
                    }
                    System.out.print("\n");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 4:
                System.out.print("Write brand: ");
                String brandSearch = scanner.nextLine();
                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
                    PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM drinktable WHERE brand = ? ");
                    preparedStatement.setString(1, brandSearch);
                    ResultSet rs = preparedStatement.executeQuery();
                    System.out.print("\n");

                    while (rs.next())
                    {
                        int ID = rs.getInt("id");
                        String name = rs.getString("name");
                        float volume = rs.getFloat("volume");
                        String brand = rs.getString("brand");
                        float price = rs.getFloat("price");
                        String isAlcoholic = rs.getString("isAlcoholic");
                        String creationType = rs.getString("creationType");
                        String drinkType = rs.getString("drinkType");

                        System.out.format("%s, %s, %s, %s, %s, %s, %s, %s\n", ID, name, volume, brand, price, isAlcoholic, creationType,  drinkType);
                    }
                    System.out.print("\n");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 5:
                System.out.print("Write price: ");
                float priceSearch = scanner.nextFloat();
                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
                    PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM drinktable WHERE price = ? ");
                    preparedStatement.setDouble(1, priceSearch);
                    ResultSet rs = preparedStatement.executeQuery();
                    System.out.print("\n");

                    while (rs.next())
                    {
                        int ID = rs.getInt("id");
                        String name = rs.getString("name");
                        float volume = rs.getFloat("volume");
                        String brand = rs.getString("brand");
                        float price = rs.getFloat("price");
                        String isAlcoholic = rs.getString("isAlcoholic");
                        String creationType = rs.getString("creationType");
                        String drinkType = rs.getString("drinkType");

                        System.out.format("%s, %s, %s, %s, %s, %s, %s, %s\n", ID, name, volume, brand, price, isAlcoholic, creationType,  drinkType);
                    }
                    System.out.print("\n");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 6:
                System.out.print("Write is drink alcoholic or nonalcoholic: ");
                String isAlcoSearch = scanner.nextLine();
                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
                    PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM drinktable WHERE isAlcoholic = ? ");
                    preparedStatement.setString(1, isAlcoSearch);
                    ResultSet rs = preparedStatement.executeQuery();
                    System.out.print("\n");

                    while (rs.next())
                    {
                        int ID = rs.getInt("id");
                        String name = rs.getString("name");
                        float volume = rs.getFloat("volume");
                        String brand = rs.getString("brand");
                        float price = rs.getFloat("price");
                        String isAlcoholic = rs.getString("isAlcoholic");
                        String creationType = rs.getString("creationType");
                        String drinkType = rs.getString("drinkType");

                        System.out.format("%s, %s, %s, %s, %s, %s, %s, %s\n", ID, name, volume, brand, price, isAlcoholic, creationType,  drinkType);
                    }
                    System.out.print("\n");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 7:
                System.out.print("Write creation type: ");
                String crTypeSearch = scanner.nextLine();
                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
                    PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM drinktable WHERE creationType = ? ");
                    preparedStatement.setString(1, crTypeSearch);
                    ResultSet rs = preparedStatement.executeQuery();
                    System.out.print("\n");

                    while (rs.next())
                    {
                        int ID = rs.getInt("id");
                        String name = rs.getString("name");
                        float volume = rs.getFloat("volume");
                        String brand = rs.getString("brand");
                        float price = rs.getFloat("price");
                        String isAlcoholic = rs.getString("isAlcoholic");
                        String creationType = rs.getString("creationType");
                        String drinkType = rs.getString("drinkType");

                        System.out.format("%s, %s, %s, %s, %s, %s, %s, %s\n", ID, name, volume, brand, price, isAlcoholic, creationType,  drinkType);
                    }
                    System.out.print("\n");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 8:
                System.out.print("Write drink type: ");
                String drTypeSearch = scanner.nextLine();
                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/drinks", "root", "12345"); Statement statement = conn.createStatement()) {
                    PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM drinktable WHERE drinkType = ? ");
                    preparedStatement.setString(1, drTypeSearch);
                    ResultSet rs = preparedStatement.executeQuery();
                    System.out.print("\n");

                    while (rs.next())
                    {
                        int ID = rs.getInt("id");
                        String name = rs.getString("name");
                        float volume = rs.getFloat("volume");
                        String brand = rs.getString("brand");
                        float price = rs.getFloat("price");
                        String isAlcoholic = rs.getString("isAlcoholic");
                        String creationType = rs.getString("creationType");
                        String drinkType = rs.getString("drinkType");

                        System.out.format("%s, %s, %s, %s, %s, %s, %s, %s\n", ID, name, volume, brand, price, isAlcoholic, creationType,  drinkType);
                    }
                    System.out.print("\n");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            default:
                System.out.println("Wrong type. Try again.");
                Menu menu = new Menu();
                menu.searchMenu();
                break;
        }
    }
}