public class JackDaniels extends Whiskey {
    @Override
    public String brand(){return "JackDaniels";};
}
