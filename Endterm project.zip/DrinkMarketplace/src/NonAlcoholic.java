abstract class NonAlcoholic implements Drinks{

    @Override
    public boolean isAlcoholic(){
        return false;
    }
    abstract String getCreationType();
}
