public class CocaCola extends Soda {
    @Override
    public String brand(){return "CocaCola";};
}
