public abstract class Water extends NonCarbonated {
    @Override
    public String nonCarbType(){return "Water";}
    abstract String brand();
}
