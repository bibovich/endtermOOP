abstract class Vodka extends Distilled {
    @Override
    public String distillationType(){return "Vodka";}
    abstract String brand();


}
