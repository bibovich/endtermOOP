abstract class Alcoholic implements Drinks{
    @Override 
    public boolean isAlcoholic(){
        return true;
    }
    abstract String getCreationType();
}
