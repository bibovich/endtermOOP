public class Danone extends Water {
    @Override
    public String brand(){return "Danone";};
}
