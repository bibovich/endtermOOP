public class Pepsico extends Soda {
    @Override
    public String brand(){return "PepsiCo";};
}
