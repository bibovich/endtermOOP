public class Barefoot extends Wine {
    @Override
    public String brand(){return "Absolut";};
}
