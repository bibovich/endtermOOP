public class NestleWaters extends Water {
    @Override
    public String brand(){return "NestleWaters";};
}
