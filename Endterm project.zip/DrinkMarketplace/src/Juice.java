public abstract class Juice extends NonCarbonated {
    @Override
    public String nonCarbType(){return "Juice";}
    abstract String brand();
}