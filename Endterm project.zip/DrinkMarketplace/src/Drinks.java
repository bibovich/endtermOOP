interface Drinks {
    boolean isAlcoholic();
}
