abstract public class Carbonated extends NonAlcoholic{
    private final String creationType = "Carbonated";

    @Override
    String getCreationType() { return creationType; }
    abstract String carbonationType();
}
