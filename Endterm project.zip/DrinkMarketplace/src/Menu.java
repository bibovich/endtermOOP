import java.util.Scanner;
public class Menu{
    Scanner scanner = new Scanner(System.in);
    SQL table = new SQL();
    Absolut absolut = new Absolut();
    Smirnoff smirnoff = new Smirnoff();
    JackDaniels jackDaniels = new JackDaniels();
    JohnnieWalker johnnieWalker = new JohnnieWalker();
    Barefoot barefoot = new Barefoot();
    ConchayToro conchayToro = new ConchayToro();
    Guinness guinness = new Guinness();
    Baltica baltica = new Baltica();
    CocaCola cocaCola = new CocaCola();
    Pepsico pepsico = new Pepsico();
    RedBull redBull = new RedBull();
    Riks riks = new Riks();
    Piko piko = new Piko();
    Rich rich = new Rich();
    Danone danone = new Danone();
    NestleWaters nestleWaters = new NestleWaters();

    public void mainMenu(){
        System.out.println("1 - Insert data. 2 - Read data. 3 - Update data. 4 - Delete data. 5 - Search Data.");
        System.out.print("Select command: ");
        int command = scanner.nextInt();

        if(command == 1){
            insertMenu();
        }else if(command == 2){
            readMenu();
        }
        else if(command == 3){
            updateMenu();
        }else if(command == 4){
            deleteMenu();
        }
        else if(command == 5){
            searchMenu();
        }
        else{
            System.out.println("Wrong command, please input correct command.");
            mainMenu();
        }
    }
    private void insertMenu(){
        System.out.println("\nData insert menu.");
        System.out.print("Input id: ");
        int id = scanner.nextInt();

        System.out.print("Input name of drink: ");
        scanner.nextLine();
        String name = scanner.nextLine();

        System.out.print("Input volume: ");
        float volume = scanner.nextFloat();

        System.out.print("Input price: ");
        float price = scanner.nextFloat();

        System.out.println("Select brand: ");
        System.out.println("1 - Absolut. 2 - Smirnoff. 3 - Jack Daniels. 4 - Jonnie Walker.");
        System.out.println("5 - Barefoot. 6 - Concha Y Toro. 7 - Guinness. 8 - Baltica.");
        System.out.println("9 - Coca-Cola. 10 - PepsiCo 11 - RedBull. 12 - Riks.");
        System.out.println("13 - Piko. 14 - Rich. 15 - Danone. 16 - NestleWaters.");
        System.out.print("Input brand number: ");
        int brand = scanner.nextInt();


        switch(brand){
            case 1:
                table.insertData(id, name, volume, absolut.brand(), price, absolut.isAlcoholic(), absolut.getCreationType(), absolut.distillationType());
                break;
            case 2:
                table.insertData(id, name, volume, smirnoff.brand(), price, smirnoff.isAlcoholic(), smirnoff.getCreationType(), smirnoff.distillationType());
                break;
            case 3:
                table.insertData(id, name, volume, jackDaniels.brand(), price, jackDaniels.isAlcoholic(), jackDaniels.getCreationType(), jackDaniels.distillationType());
                break;
            case 4:
                table.insertData(id, name, volume, johnnieWalker.brand(), price, johnnieWalker.isAlcoholic(), johnnieWalker.getCreationType(), johnnieWalker.distillationType());
                break;
            case 5:
                table.insertData(id, name, volume, barefoot.brand(), price, barefoot.isAlcoholic(), barefoot.getCreationType(), barefoot.fermentedType());
                break;
            case 6:
                table.insertData(id, name, volume, conchayToro.brand(), price, conchayToro.isAlcoholic(), conchayToro.getCreationType(), conchayToro.fermentedType());
                break;
            case 7:
                table.insertData(id, name, volume, guinness.brand(), price, guinness.isAlcoholic(), guinness.getCreationType(), guinness.fermentedType());
                break;
            case 8:
                table.insertData(id, name, volume, baltica.brand(), price, baltica.isAlcoholic(), baltica.getCreationType(), baltica.fermentedType());
                break;
            case 9:
                table.insertData(id, name, volume, cocaCola.brand(), price, cocaCola.isAlcoholic(), cocaCola.getCreationType(), cocaCola.carbonationType());
                break;
            case 10:
                table.insertData(id, name, volume, pepsico.brand(), price, pepsico.isAlcoholic(), pepsico.getCreationType(), pepsico.carbonationType());
                break;
            case 11:
                table.insertData(id, name, volume, redBull.brand(), price, redBull.isAlcoholic(), redBull.getCreationType(), redBull.carbonationType());
                break;
            case 12:
                table.insertData(id, name, volume, riks.brand(), price, riks.isAlcoholic(), riks.getCreationType(), riks.carbonationType());
                break;
            case 13:
                table.insertData(id, name, volume, piko.brand(), price, piko.isAlcoholic(), piko.getCreationType(), piko.nonCarbType());
                break;
            case 14:
                table.insertData(id, name, volume, rich.brand(), price, rich.isAlcoholic(), rich.getCreationType(), rich.nonCarbType());
                break;
            case 15:
                table.insertData(id, name, volume, danone.brand(), price, danone.isAlcoholic(), danone.getCreationType(), danone.nonCarbType());
                break;
            case 16:
                table.insertData(id, name, volume, nestleWaters.brand(), price, nestleWaters.isAlcoholic(), nestleWaters.getCreationType(), nestleWaters.nonCarbType());
                break;
        }
        System.out.println("\nData has inserted successful!\n");
        mainMenu();
    }
    public void readMenu(){
        System.out.println("\nData read all data menu.");
        System.out.println("Here all data from table: ");
        table.readData();
        mainMenu();
    }

    public void updateMenu(){
        System.out.println("\nData update menu.");
        table.readData();
        System.out.print("What drink data do you want to update? Write it's id: ");
        int id = scanner.nextInt();
        System.out.println("What data type do you want to update?");
        System.out.println("1 - ID. 2 - Name. 3 - Volume. 4 - Brand. 5 - Price.");
        System.out.print("Select type: ");
        int type = scanner.nextInt();

        if(type == 1){
            System.out.print("Insert new id: ");
            int newId = scanner.nextInt();
            table.updateIdData(newId, id);
            System.out.println("\nData updated successful!\n");
            mainMenu();
        }else if(type == 2){
            System.out.print("Insert new name: ");
            scanner.nextLine();
            String newName = scanner.nextLine();
            table.updateNameData(newName, id);
            System.out.println("\nData updated successful!\n");
            mainMenu();
        }else if(type == 3){
            System.out.print("Insert new volume: ");
            float newVolume = scanner.nextFloat();
            table.updateVolumeData(newVolume, id);
            System.out.println("\nData updated successful!\n");
            mainMenu();
        }else if(type == 4){
            updateBrandMenu(id);
        }else if(type == 5){
            System.out.print("Insert new price: ");
            float newPrice = scanner.nextFloat();
            table.updatePriceData(newPrice, id);
            System.out.println("\nData updated successful!\n");
            mainMenu();
        }else{
            System.out.println("Wrong type. Try again.");
            updateMenu();
        }
    }

    public void updateBrandMenu(int id){
        System.out.println("Select new brand: ");
        System.out.println("1 - Absolut. 2 - Smirnoff. 3 - Jack Daniels. 4 - Jonnie Walker.");
        System.out.println("5 - Barefoot. 6 - Concha Y Toro. 7 - Guinness. 8 - Baltica.");
        System.out.println("9 - Coca-Cola. 10 - PepsiCo 11 - RedBull. 12 - Riks.");
        System.out.println("13 - Piko. 14 - Rich. 15 - Danone. 16 - NestleWaters.");
        System.out.print("Input brand number: ");
        int brand = scanner.nextInt();


        switch(brand){
            case 1:
                table.updateBrandData(absolut.brand(), absolut.isAlcoholic(), absolut.getCreationType(), absolut.distillationType(), id);
                break;
            case 2:
                table.updateBrandData(smirnoff.brand(), smirnoff.isAlcoholic(), smirnoff.getCreationType(), smirnoff.distillationType(), id);
                break;
            case 3:
                table.updateBrandData(jackDaniels.brand(), jackDaniels.isAlcoholic(), jackDaniels.getCreationType(), jackDaniels.distillationType(), id);
                break;
            case 4:
                table.updateBrandData(johnnieWalker.brand(), johnnieWalker.isAlcoholic(), johnnieWalker.getCreationType(), johnnieWalker.distillationType(), id);
                break;
            case 5:
                table.updateBrandData(barefoot.brand(), barefoot.isAlcoholic(), barefoot.getCreationType(), barefoot.fermentedType(), id);
                break;
            case 6:
                table.updateBrandData(conchayToro.brand(), conchayToro.isAlcoholic(), conchayToro.getCreationType(), conchayToro.fermentedType(), id);
                break;
            case 7:
                table.updateBrandData(guinness.brand(), guinness.isAlcoholic(), guinness.getCreationType(), guinness.fermentedType(), id);
                break;
            case 8:
                table.updateBrandData(baltica.brand(), baltica.isAlcoholic(), baltica.getCreationType(), baltica.fermentedType(), id);
                break;
            case 9:
                table.updateBrandData(cocaCola.brand(), cocaCola.isAlcoholic(), cocaCola.getCreationType(), cocaCola.carbonationType(), id);
                break;
            case 10:
                table.updateBrandData(pepsico.brand(), pepsico.isAlcoholic(), pepsico.getCreationType(), pepsico.carbonationType(), id);
                break;
            case 11:
                table.updateBrandData(redBull.brand(), redBull.isAlcoholic(), redBull.getCreationType(), redBull.carbonationType(), id);
                break;
            case 12:
                table.updateBrandData(riks.brand(), riks.isAlcoholic(), riks.getCreationType(), riks.carbonationType(), id);
                break;
            case 13:
                table.updateBrandData(piko.brand(), piko.isAlcoholic(), piko.getCreationType(), piko.nonCarbType(), id);
                break;
            case 14:
                table.updateBrandData(rich.brand(), rich.isAlcoholic(), rich.getCreationType(), rich.nonCarbType(), id);
                break;
            case 15:
                table.updateBrandData(danone.brand(), danone.isAlcoholic(), danone.getCreationType(), danone.nonCarbType(), id);
                break;
            case 16:
                table.updateBrandData(nestleWaters.brand(), nestleWaters.isAlcoholic(), nestleWaters.getCreationType(), nestleWaters.nonCarbType(), id);
                break;
        }

        System.out.println("\nData updated successful!\n");
        mainMenu();
    }

    public void deleteMenu(){
        System.out.println("\nData update menu.");
        System.out.println("Delete specific or all data?");
        System.out.println("1 - Specific data. 2 - All data.");
        System.out.print("Choose command: ");
        int command = scanner.nextInt();

        if (command == 1){
            table.readData();
            System.out.print("What drink data do you want to delete? Write it's id: ");
            int id = scanner.nextInt();
            table.deleteData(id);
            System.out.println("\nData has deleted.\n");
            mainMenu();
        }else if(command == 2){
            table.deleteAllData();
            System.out.println("\nAll data has deleted.\n");
            mainMenu();
        }
    }

    public void searchMenu(){
        System.out.println("\nData search menu.");
        System.out.println("1 - ID. 2 - Name. 3 - Volume. 4 - Brand. 5 - Price. 6 - Is Alcoholic. 7 - Creation Type. 8 - Drink Type.");
        System.out.print("Select data type: ");
        int type = scanner.nextInt();
        table.searchData(type);
        mainMenu();
    }
}
