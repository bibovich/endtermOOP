public class Main {
    public static void main(String[] args){
        System.out.println("Welcome to our program to manage Drink Marketplace!. There is menu below.");
        Menu menu = new Menu();
        menu.mainMenu();
    }
}
