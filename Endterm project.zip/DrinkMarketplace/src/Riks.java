public class Riks extends Energetic {
    @Override
    public String brand(){return "Riks";};
}
