public abstract class Energetic extends Carbonated {
    @Override
    public String carbonationType(){return "Energetic";}
    abstract String brand();
}