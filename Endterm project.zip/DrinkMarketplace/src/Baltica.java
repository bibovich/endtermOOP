public class Baltica extends Beer {
    @Override
    public String brand(){return "Baltica";};
}
