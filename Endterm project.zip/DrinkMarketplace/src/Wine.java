abstract class Wine extends Fermented {
    @Override
    public String fermentedType(){return "Wine";}
    abstract String brand();
}
