public class Rich extends Juice{
    @Override
    public String brand(){return "Rich";};
}
