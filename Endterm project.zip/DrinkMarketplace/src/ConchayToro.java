public class ConchayToro extends Wine {
    @Override
    public String brand(){return "Absolut";};
}
