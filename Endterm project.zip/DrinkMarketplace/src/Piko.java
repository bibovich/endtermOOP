public class Piko extends Juice {
    @Override
    public String brand(){return "Piko";};
}
