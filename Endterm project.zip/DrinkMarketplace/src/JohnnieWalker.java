public class JohnnieWalker extends Whiskey {
    @Override
    public String brand(){return "Absolut";};
}
