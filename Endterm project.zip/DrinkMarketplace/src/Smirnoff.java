public class Smirnoff extends Vodka {
    @Override
    public String brand(){return "Smirnoff";};
}
