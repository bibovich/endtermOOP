abstract class Whiskey extends Distilled {
    @Override
    public String distillationType(){return "Whiskey";}
    abstract String brand();
}
