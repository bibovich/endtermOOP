public class RedBull extends Energetic {
    @Override
    public String brand(){return "RedBull";};
}
