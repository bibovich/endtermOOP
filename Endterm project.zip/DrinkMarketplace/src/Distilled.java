abstract class Distilled extends Alcoholic {
    private final String creationType = "Distilled";

    @Override
    String getCreationType() { return creationType; }
    abstract String distillationType();
}
