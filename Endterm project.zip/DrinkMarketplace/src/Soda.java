public abstract class Soda extends Carbonated {
    @Override
    public String carbonationType(){return "Soda";}
    abstract String brand();

}