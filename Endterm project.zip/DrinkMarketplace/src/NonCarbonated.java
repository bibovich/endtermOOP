abstract public class NonCarbonated extends NonAlcoholic{
    private final String creationType = "NonCarbonated";

    @Override
    String getCreationType() { return creationType; }
    abstract String nonCarbType();
}
